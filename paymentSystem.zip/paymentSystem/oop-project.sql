
select* from payment_detail
 insert into payment_details values (0,);payment_details2