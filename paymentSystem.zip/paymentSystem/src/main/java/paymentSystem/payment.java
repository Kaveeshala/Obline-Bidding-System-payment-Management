package paymentSystem;
    //This is the java class

public class payment{
	private int id;
	private String name;
	private String email;
	private String address;
	private String city;
	private String phonenumber;
	private String zip_code;
	private String name_on_card;
	private String credit_card_number;
	private String exp_month;
	private String exp_year;
	private String cvv;
	
	public payment(int id, String name, String email, String address, String city, String phonenumber, String zip_code,
			String name_on_card, String credit_card_number, String exp_month, String exp_year, String cvv)
	
	{
		
		//this.id = id;
		///this.name = name;
		//this.email = email;
		this.address = address;
		this.city = city;
		this.phonenumber = phonenumber;
		this.zip_code = zip_code;
		this.name_on_card = name_on_card;
		this.credit_card_number = credit_card_number;
		this.exp_month = exp_month;
		this.exp_year = exp_year;
		this.cvv = cvv;
	}

	public payment(int i, Object name, Object email) {
		// TODO Auto-generated constructor stub
		
	}

	public payment() {
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public String getZip_code() {
		return zip_code;
	}

	public void setZip_code(String zip_code) {
		this.zip_code = zip_code;
	}

	public String getName_on_card() {
		return name_on_card;
	}

	public void setName_on_card(String name_on_card) {
		this.name_on_card = name_on_card;
	}

	public String getCredit_card_number() {
		return credit_card_number;
	}

	public void setCredit_card_number(String credit_card_number) {
		this.credit_card_number = credit_card_number;
	}

	public String getExp_month() {
		return exp_month;
	}

	public void setExp_month(String exp_month) {
		this.exp_month = exp_month;
	}

	public String getExp_year() {
		return exp_year;
	}

	public void setExp_year(String exp_year) {
		this.exp_year = exp_year;
	}

	public String getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv = cvv;
	}

	

	
	
	

}
