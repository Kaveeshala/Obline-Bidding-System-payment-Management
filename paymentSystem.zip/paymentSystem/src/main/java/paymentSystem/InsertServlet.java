package paymentSystem;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/insert")
public class InsertServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String url = "jdbc:mysql://localhost:3306/bidingvortex";
        String user = "root";
        String password = "Nayanamini@2003";

        try {
            String fullname = request.getParameter("fullname");
            String email = request.getParameter("email");
            String address = request.getParameter("address");
            String city = request.getParameter("city");
            String phonenumber = request.getParameter("phonenumber");
            String zipcode = request.getParameter("zipcode");
            String name_on_card = request.getParameter("name_on_card");
            String credit_card_number = request.getParameter("credit_card_number");
            String exp_month = request.getParameter("exp_month");
            String exp_year = request.getParameter("exp_year");
            String cvv = request.getParameter("cvv");

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(url, user, password);

            String insertQuery = "INSERT INTO payment_details2 (name, email, address, city, phonenumber, zip_code, name_on_card, credit_card_number, exp_month, exp_year, cvv) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);

            preparedStatement.setString(1, fullname);
            preparedStatement.setString(2, email);
            preparedStatement.setString(3, address);
            preparedStatement.setString(4, city);
            preparedStatement.setString(5, phonenumber);
            preparedStatement.setString(6, zipcode);
            preparedStatement.setString(7, name_on_card);
            preparedStatement.setString(8, credit_card_number);
            preparedStatement.setString(9, exp_month);
            preparedStatement.setString(10, exp_year);
            preparedStatement.setString(11, cvv);

            preparedStatement.executeUpdate();

            connection.close();

            // Redirect to detailshow.jsp after successful insertion
            response.sendRedirect("detailshow.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}
