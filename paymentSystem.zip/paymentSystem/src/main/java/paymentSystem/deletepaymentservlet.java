package paymentSystem;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/delete")
public class deletepaymentservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String id = request.getParameter("payId");
		boolean isTrue;
		isTrue = paymentDBUtil.deletePayment(id);
		
		 if(isTrue == true) {
				RequestDispatcher dis= request.getRequestDispatcher("detailshow.jsp");
				dis.forward(request, response);
			}
			else {
				List<payment> paydetails = paymentDBUtil.getPaymentDetails(id);
				request.setAttribute("paydetails", paydetails);
				RequestDispatcher dis= request.getRequestDispatcher("paymentdetail.jsp");
				dis.forward(request, response);
				
	
			}
	}
	
}


