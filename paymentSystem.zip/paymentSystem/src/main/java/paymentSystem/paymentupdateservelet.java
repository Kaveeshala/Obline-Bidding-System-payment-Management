package paymentSystem;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/update")
public class paymentupdateservelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String name = request.getParameter("fullname"); 
		String email = request.getParameter("email");
		String address = request.getParameter("address");
		String city = request.getParameter("city");
		String phonenumber = request.getParameter("phonenumber");
		String zipcode = request.getParameter("zipcode");
		String nameoncard = request.getParameter("name_on_card");
		String creditcardnumber = request.getParameter("credit_card_number");
		String expyear = request.getParameter("exp_month");
		String expmonth = request.getParameter("exp_year");
		String cvv = request.getParameter("cvv");
		

		 boolean isTrue;
		 isTrue = paymentDBUtil.paymentupdate(cvv, name, email, address, city, phonenumber, zipcode, nameoncard, creditcardnumber, expyear, expmonth, cvv);
		 
		 if(isTrue == true) {
				RequestDispatcher dis= request.getRequestDispatcher("detailshow.jsp");
				dis.forward(request, response);
			}
			else {
				RequestDispatcher dis2= request.getRequestDispatcher("paymentdetail.jsp");
				dis2.forward(request, response);
			}
	}
	
}

