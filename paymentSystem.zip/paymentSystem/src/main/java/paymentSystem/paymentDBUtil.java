package paymentSystem;

//entity class

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class paymentDBUtil {
	
	      private static boolean isSucess;
	      private static Connection con= null;
	      private static Statement stat=null;
	      
	//create a method
			public static boolean insertpaymentDetails(String name,String email,String address,String city ,String phonenumber,String zipcode,String nameoncard,String creditcardnumber,String expyear,String expmonth,String cvv) {
				boolean isSucess = false;
				
				System.out.println("awa methenata");
				System.out.println(name);
				System.out.println(email);
				System.out.println(address);
				System.out.println(city);
			    //validate
			    try {
			    	con = DBConnection.getConnection();
			    	stat = con.createStatement();
			    	Statement stat = con.createStatement();
			    	String sql = "Insert into payment_details2 value (0,'"+name+"','"+email+"','"+address+"','"+phonenumber+"','"+zipcode+"','"+nameoncard+"','"+creditcardnumber+"','"+expmonth+"','"+expyear+"','"+cvv+"')";
			    	int rs = stat.executeUpdate(sql);
			    	
			    	if(rs>0) {
			    		isSucess = true;
			    	}
			    	else {
			    		isSucess = false;
			    	}
			    			
			    }
			    catch(Exception e){
			    	e.printStackTrace();
			    }  
				return isSucess;	
			
           }
			public static List<payment> viewdata(String name,String email,String address,String city ,String phonenumber,String zipcode,String nameoncard,String creditcardnumber,String expyear,String expmonth,String cvv) {
				ArrayList<payment> pay= new ArrayList<>();
				try {
					con = DBConnection.getConnection();
					 stat = con.createStatement();
					String sql = "Select *from payment_details2 set name='"+name+"',email='"+email+"',address='"+address+"',city='"+city+"',phonenumber='"+phonenumber+"',zip_code='"+zipcode+"',name_on_card='"+nameoncard+"',credit_card_number='"+creditcardnumber+"',exp_month='"+expmonth+"',exp_year='"+expyear+"',cvv='"+cvv+"'";
					ResultSet rs = stat.executeQuery(sql);
					
					if(rs.next()) {
					 int id=rs.getInt(1);
			    	  name =rs.getString(2);
			    	  email=rs.getString(3);
			    	  address=rs.getString(4);
			    	  city=rs.getString(5);
			    	  phonenumber =rs.getString(6);
			    	  zipcode=rs.getString(7);
			    	  nameoncard=rs.getString(8);
			    	  creditcardnumber =rs.getString(9);
			    	  expmonth=rs.getString(10);
			    	  expyear=rs.getString(11);
			    	  cvv=rs.getString(12);
			    		
			    		payment p= new payment(id,name,email,address,city,phonenumber,zipcode,nameoncard,creditcardnumber,expmonth,expyear,cvv);
			    		pay.add(p);
			    	}
			    	
					
				}catch(Exception e) {
					e.printStackTrace();
				}
				
				return pay;
			}
				
				
		
			public static boolean paymentupdate(String id,String name,String email,String address,String city ,String phonenumber,String zipcode,String nameoncard,String creditcardnumber,String expyear,String expmonth,String cvv) {
				
				boolean isSucess = false;
				try {
					con = DBConnection.getConnection();
					 stat = con.createStatement();
					String sql = "Update payment_details2 set name='"+name+"',email='"+email+"',address='"+address+"',phonenumber='"+phonenumber+"',zip_code='"+zipcode+"',name_on_card='"+nameoncard+"',credit_card_number='"+creditcardnumber+"',exp_month='"+expmonth+"',exp_year='"+expyear+"',cvv='"+cvv+"'"
							+ "where id='"+id+"'";
					int rs = stat.executeUpdate(sql);
					
					if(rs>0) {
			    		isSucess = true;
			    	}
			    	else {
			    		isSucess = false;
			    	}
					
				}catch(Exception e) {
					e.printStackTrace();
				}
				
				return isSucess;
			}
			
			public static List<payment> getPaymentDetails (String id){
				int convertedID = Integer.parseInt(id) ;
				ArrayList<payment> pay = new ArrayList<>();
				
				
				try {
					con = DBConnection.getConnection();
			    	stat = con.createStatement();
			    	Statement stat = con.createStatement();
			    	String sql = "SELECT * FROM payment_details2 WHERE id='"+convertedID+"'"; 
			    	ResultSet rs = stat.executeQuery(sql);
			    	
			    	while(rs.next()) {
			    		int id1 = rs.getInt(1);
			    		String name = rs.getString(2);
			    		String email = rs.getString(3);
			    		String address = rs.getString(4);
			    		String city = rs.getString(5);
			    		String phonenumber = rs.getString(6);
			    		String zip_code = rs.getString(7);
			    		String name_on_card = rs.getString(8);
			    		String credit_card_number = rs.getString(9);
			    		String exp_month = rs.getString(10);
			    		String exp_year = rs.getString(11);
			    		String cvv = rs.getString(12);
			    		
			    		payment p = new payment(id1,name,email,address,city,phonenumber,zip_code,name_on_card,credit_card_number,exp_month,exp_year,cvv);
			    		pay.add(p);
			    	}
			    	
					
				}
				catch(Exception e) {
					e.printStackTrace();
				}
				return pay;	
			}
			public static boolean deletePayment(String id) {
				
				int convid = Integer.parseInt(id);
				
				try {
					con = DBConnection.getConnection();
					 stat = con.createStatement();
					String sql = "Delete from payment_details2 where id='"+convid+"'";
					int rs = stat.executeUpdate(sql);
					
					if(rs>0) {
			    		isSucess = true;
			    	}
			    	else {
			    		isSucess = false;
			    	}
				
				}
				catch(Exception e) {
					e.printStackTrace();	
				}
				
				return isSucess;
				
			}
			
			
}
	
		
	



	