package paymentSystem;

import java.sql.Connection;
import java.sql.DriverManager;

//create connection to database

public class DBConnection {

	private static String JDBC_URL = "jdbc:mysql://localhost:3306/bidingvortex";
    private static String DB_USER = "root";
    private static String DB_PASSWORD = "Nayanamini@2003";
    private static Connection con;
    
    
    public static Connection getConnection() {
    	
    	try {
    		Class.forName("com.mysql.jdk.Driver");
    		 con = DriverManager.getConnection(JDBC_URL,DB_USER,DB_PASSWORD);
    		
    	}
    	catch(Exception e){
    		System.out.println("Database connection is not success");
    	}
    	return con;
    }
    
}
